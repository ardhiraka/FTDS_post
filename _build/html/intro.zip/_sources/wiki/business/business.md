# Business Accumen

Welcome to Business Accumen Wiki!
